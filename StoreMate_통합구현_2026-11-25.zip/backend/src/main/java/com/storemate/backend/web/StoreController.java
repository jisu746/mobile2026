// 매장 생성, 초대 코드 조회, 참여 요청, 승인/거절 API
package com.storemate.backend.web;

import com.storemate.backend.domain.*;
import com.storemate.backend.repo.StoreMemberRepository;
import com.storemate.backend.repo.StoreRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class StoreController {
    private final StoreRepository stores;
    private final StoreMemberRepository members;
    private final SecureRandom random = new SecureRandom();
    private final boolean autoApprove;
    private final ProductSeeder seeder;
    private final Notifier notifier;
    private final boolean anyQr;

    public StoreController(StoreRepository stores, StoreMemberRepository members, ProductSeeder seeder, Notifier notifier,
                           @Value("${storemate.dev.auto-approve:false}") boolean autoApprove,
                           @Value("${storemate.dev.any-qr:false}") boolean anyQr) {
        this.stores = stores;
        this.members = members;
        this.autoApprove = autoApprove;
        this.seeder = seeder;
        this.notifier = notifier;
        this.anyQr = anyQr;
    }

    // 초대 코드로 매장을 찾는다. 개발용 any-qr 일 때는 없는 코드도 가장 최근에 만든 매장으로 본다
    private Store byCode(String code) {
        return stores.findByInviteCode(code == null ? "" : code.trim().toUpperCase())
                .or(() -> anyQr ? stores.findFirstByOrderByIdDesc() : Optional.empty())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "초대 코드에 해당하는 매장이 없어요"));
    }

    // 초대 코드: 영문 대문자 3자 + 숫자 4자 (예: DLB-4821), 겹치면 다시 뽑는다
    private String newInviteCode() {
        for (int i = 0; i < 50; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < 3; j++) sb.append((char) ('A' + random.nextInt(26)));
            sb.append('-').append(1000 + random.nextInt(9000));
            if (!stores.existsByInviteCode(sb.toString())) return sb.toString();
        }
        throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "초대 코드를 만들지 못했어요");
    }

    private static String clean(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }

    @PostMapping("/stores")
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    Dto.StoreView create(@RequestAttribute(AuthInterceptor.ACCOUNT) Account account, @RequestBody Dto.CreateStoreRequest r) {
        if (account.getRole() != Role.OWNER) throw new ApiException(HttpStatus.FORBIDDEN, "사장님만 매장을 등록할 수 있어요");
        if (clean(r.name()) == null) throw new ApiException(HttpStatus.BAD_REQUEST, "매장 이름을 입력해주세요");
        if (clean(r.address()) == null) throw new ApiException(HttpStatus.BAD_REQUEST, "매장 주소를 입력해주세요");
        Store s = stores.save(new Store(clean(r.name()), clean(r.type()), clean(r.branch()), clean(r.address()),
                clean(r.addressDetail()), clean(r.openTime()), clean(r.closeTime()), newInviteCode(), account));
        members.save(new StoreMember(account, s, Role.OWNER, MemberStatus.APPROVED));
        seeder.seed(s);
        return AccountViews.store(s, true);
    }

    // 초대 코드(또는 QR)로 매장을 찾는다. 참여 요청 전에 어떤 매장인지 보여주는 용도
    @GetMapping("/stores/lookup")
    Dto.StoreSummary lookup(@RequestParam String code) {
        Store s = byCode(code);
        return new Dto.StoreSummary(s.getName(), s.getType(), s.getBranch(), s.getOwner().getName());
    }

    @PostMapping("/stores/join")
    @Transactional
    Dto.JoinResponse join(@RequestAttribute(AuthInterceptor.ACCOUNT) Account account, @RequestBody Dto.JoinRequest r) {
        if (account.getRole() != Role.STAFF) throw new ApiException(HttpStatus.FORBIDDEN, "직원만 매장에 참여할 수 있어요");
        Store s = byCode(r.code());
        StoreMember m = members.findByAccountAndStore(account, s).orElse(null);
        if (m == null) {
            m = members.save(new StoreMember(account, s, Role.STAFF, autoApprove ? MemberStatus.APPROVED : MemberStatus.PENDING));
        } else if (m.getStatus() == MemberStatus.APPROVED) {
            throw new ApiException(HttpStatus.CONFLICT, "이미 참여 중인 매장이에요");
        } else if (m.getStatus() == MemberStatus.REJECTED) {
            m.setStatus(autoApprove ? MemberStatus.APPROVED : MemberStatus.PENDING); // 거절됐던 요청은 다시 보낼 수 있다
        }
        notifier.send(s, Role.OWNER, account, "join", account.getName() + " 님이 매장 참여를 요청했어요", "초대 코드 · " + account.getUsername());
        return new Dto.JoinResponse(m.getStatus().name().toLowerCase());
    }

    // ---- 사장님: 참여 요청 목록과 승인/거절 (앱 화면은 아직 없음) ----

    private Store ownedStore(Account account, Long storeId) {
        Store s = stores.findById(storeId).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "매장을 찾을 수 없어요"));
        if (!s.getOwner().getId().equals(account.getId())) throw new ApiException(HttpStatus.FORBIDDEN, "내 매장이 아니에요");
        return s;
    }

    @GetMapping("/stores/{id}/requests")
    @Transactional(readOnly = true)
    List<Dto.MemberRequestView> requests(@RequestAttribute(AuthInterceptor.ACCOUNT) Account account, @PathVariable Long id) {
        Store s = ownedStore(account, id);
        return members.findByStoreAndStatusOrderByIdAsc(s, MemberStatus.PENDING).stream()
                .map(m -> new Dto.MemberRequestView(m.getId(), m.getAccount().getUsername(), m.getAccount().getName(),
                        m.getRequestedAt().toString(), m.getWorkPart()))
                .toList();
    }

    @PostMapping("/members/{id}/{decision}")
    @Transactional
    Dto.JoinResponse decide(@RequestAttribute(AuthInterceptor.ACCOUNT) Account account, @PathVariable Long id, @PathVariable String decision,
                            @RequestBody(required = false) Dto.MemberDecisionRequest body) {
        StoreMember m = members.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "요청을 찾을 수 없어요"));
        ownedStore(account, m.getStore().getId());
        if (m.getRole() != Role.STAFF || m.getStatus() != MemberStatus.PENDING)
            throw new ApiException(HttpStatus.CONFLICT, "대기 중인 직원 요청만 처리할 수 있어요. 목록을 새로고침해 주세요");
        if ("approve".equals(decision)) {
            if (body != null && body.workPart() != null) m.setWorkPart(MemberController.validWorkPart(body.workPart()));
            m.setStatus(MemberStatus.APPROVED);
        }
        else if ("reject".equals(decision)) m.setStatus(MemberStatus.REJECTED);
        else throw new ApiException(HttpStatus.BAD_REQUEST, "처리 방식이 올바르지 않아요");
        return new Dto.JoinResponse(m.getStatus().name().toLowerCase());
    }
}
