import {installPushHandler} from './src/pushRegistration';
// 앱 전체 화면 전환(로그인, 가입, 매장 설정, 사장님/직원 홈)과 로그인 상태 관리
import { useEffect, useRef, useState } from 'react';
import { useFonts } from 'expo-font';
import { BackHandler, Platform, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as auth from './src/auth';
import Login from './src/Login';
import OwnerHome from './src/OwnerHome';
import Profile from './src/Profile';
import Signup from './src/Signup';
import StaffHome from './src/StaffHome';
import StoreSwitcher from './src/StoreSwitcher';
import StaffJoin from './src/StaffJoin';
import StoreSetup, { NewStore } from './src/StoreSetup';

import { saveStoreSetupSettings } from './src/storeSetupRepository';

// 화면 수가 적어서 네비게이션 라이브러리 없이 상태로 전환
// login / s1~s4: 회원가입 / o1~o3: 사장님 매장 등록 / f1~f4: 직원 매장 참여 / home, shome: 사장님, 직원 메인
// 프로필은 메인 위에 덮어서 띄운다 (메인의 상태를 유지하기 위해)
type Screen = 'login' | 's1' | 's2' | 's3' | 's4' | 'o1' | 'o2' | 'o3' | 'f1' | 'f2' | 'f3' | 'f4' | 'home' | 'shome';
const BACK: Record<Screen, Screen | null> = {
  login: null, home: null, shome: null, s1: 'login', s2: 's1', s3: 's2', s4: 'login',
  o1: 'login', o2: 'o1', o3: 'o2',
  f1: 'login', f2: 'f1', f3: 'f1', f4: 'login',
};

const homeOf = (acc: auth.Account): Screen => (acc.role === 'owner' ? 'home' : 'shome');
// 매장이 있으면 메인, 참여 요청을 보내 둔 직원은 승인 대기, 아니면 첫 로그인(매장 등록/참여) 화면
const startScreen = (acc: auth.Account): Screen =>
  acc.stores.length ? homeOf(acc) : acc.pending ? 'f3' : acc.role === 'owner' ? 'o1' : 'f1';

const FRAME = { width: 360, height: 800, maxHeight: '100%' as const, alignSelf: 'center' as const };

export default function App() {
  useEffect(()=>{void installPushHandler().catch(()=>{});},[]);
  const [fontsLoaded] = useFonts({ NotoSansKR: require('./assets/NotoSansKR-VF.ttf') });
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState<Screen>('login');
  const [userId, setUserId] = useState('');
  const [account, setAccount] = useState<auth.Account | null>(null);
  const [switcher, setSwitcher] = useState(false); // 프로필 아이콘의 매장 변경 시트
  const joinBase = useRef(0); // 참여 요청을 보낼 때의 소속 매장 수 (늘어나면 승인된 것)

  const store = account?.stores[account.current] ?? { name: '', type: '' };

  // 매장 등록/참여 화면에서 뒤로: 이미 매장이 있으면(매장 추가 중) 메인으로
  const backOf = (sc: Screen): Screen | null =>
    (sc === 'o1' || sc === 'f1') && account?.stores.length ? homeOf(account) : BACK[sc];

  const enter = async (id: string, acc: auth.Account) => {
    const restored = acc;
    setUserId(id);
    setAccount(restored);
    joinBase.current = restored.stores.length;
    setScreen(startScreen(restored));
  };

  // 새로 생긴 매장을 현재 매장으로 선택한다
  const selectLast = async (acc: auth.Account) => {
    const next = { ...acc, current: Math.max(acc.stores.length - 1, 0) };
    await auth.setCurrent(userId, next.current);
    setAccount(next);
    return next;
  };

  // 사장님: 매장 등록 (초대 코드를 돌려준다)
  const createStore = async (data: NewStore) => {
    const { workParts, expirationAlertDays, lowStockThresholdCount, ...storeData } = data;
    const created = await auth.createStore(storeData);
    if (created.id) {
      await saveStoreSetupSettings(created.id, { workParts, expirationAlertDays, lowStockThresholdCount });
    }
    await selectLast((await auth.refresh()).acc);
    return created.inviteCode ?? '';
  };

  // 직원: 참여 요청 보내기 / 승인 결과 확인
  const joinStore = async (code: string) => {
    joinBase.current = account?.stores.length ?? 0;
    await auth.joinStore(code);
  };
  const pollJoin = async () => {
    const { acc } = await auth.refresh();
    if (acc.pending) return 'pending' as const;
    if (acc.stores.length > joinBase.current) {
      await selectLast(acc);
      return 'approved' as const;
    }
    return 'rejected' as const;
  };

  const changeStore = async (i: number) => {
    if (!account) return;
    await auth.setCurrent(userId, i);
    setAccount({ ...account, current: i });
  };

  const logout = async () => {
    await auth.logout();
    setSwitcher(false);
    setAccount(null);
    setScreen('login');
  };

  useEffect(() => {
    auth.session().then(async (ss) => {
      if (ss) await enter(ss.id, ss.acc);
      setReady(true);
    });
  }, []);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      const prev = backOf(screen);
      if (!prev) return false;
      setScreen(prev);
      return true;
    });
    return () => sub.remove();
  }, [screen, account]);

  // MY 탭 화면 (사장님·직원 메인의 하단 탭에서 보여준다)
  const renderMy = (onBell: () => void, onRecords: () => void, onEmployeeRequests?: () => void, onEmployees?: () => void, onPayroll?: () => void, onContracts?: () => void) =>
    account && (
      <Profile
        id={userId}
        acc={account}
        onSelect={changeStore}
        onAdd={() => setScreen(account.role === 'owner' ? 'o1' : 'f1')}
        onLogout={logout}
        onBell={onBell}
        onRecords={onRecords}
        onEmployeeRequests={onEmployeeRequests ?? (() => {})}
        onEmployees={onEmployees ?? (() => {})}
        onPayroll={onPayroll ?? (() => {})}
        onContracts={onContracts ?? (() => {})}
        onSaveProfile={async ({name,birth,storeName})=>{
          if(!account)throw new Error('다시 로그인해 주세요.');
          const store=account.stores[account.current];
          const updated=await auth.updateProfile({username:userId,name,birth,expectedName:account.name,expectedBirth:account.birth??'',
            ...(account.role==='owner'&&store&&storeName!==undefined?{storeId:store.id,storeName,expectedStoreName:store.baseName??store.name}:{})});
          setAccount(current=>current===account?updated:current);
        }}
      />
    );

  if (!ready || !fontsLoaded) return null;

  return (
    <SafeAreaProvider>
      {/* 웹에서는 시안 크기(360×800) 화면 하나로 보여준다. 폰에서는 기기 화면을 그대로 쓴다. */}
      <View style={{ flex: 1, justifyContent: 'center', backgroundColor: Platform.OS === 'web' ? '#444' : '#fff' }}>
      <SafeAreaView style={[{ backgroundColor: '#fff' }, Platform.OS === 'web' ? FRAME : { flex: 1 }]}>
        <StatusBar style="dark" />
        {screen === 'login' && <Login onSignup={() => setScreen('s1')} onLoggedIn={enter} />}
        {screen[0] === 'f' && (
          <StaffJoin
            step={Number(screen[1]) as 1 | 2 | 3 | 4}
            onStep={(n) => setScreen(`f${n}` as Screen)}
            onBack={() => setScreen(backOf(screen) ?? 'login')}
            onJoin={joinStore}
            onPoll={pollJoin}
            pending={account?.pending}
            onDone={() => setScreen('shome')}
          />
        )}
        {screen === 'shome' && <StaffHome storeId={store.id ?? 0} storeName={store.name} userId={userId} userName={account?.name ?? ''} renderMy={renderMy} onSwitchStore={() => setSwitcher(true)} />}
        {screen[0] === 's' && screen !== 'shome' && (
          <Signup
            step={Number(screen[1]) as 1 | 2 | 3 | 4}
            onStep={(n) => setScreen(`s${n}` as Screen)}
            onBack={() => setScreen(BACK[screen] ?? 'login')}
            onDone={() => setScreen('login')}
          />
        )}
        {screen[0] === 'o' && (
          <StoreSetup
            step={Number(screen[1]) as 1 | 2 | 3}
            onStep={(n) => setScreen(`o${n}` as Screen)}
            onBack={account?.stores.length ? () => setScreen(backOf(screen) ?? 'login') : undefined}
            onCreate={createStore}
            onDone={() => setScreen('home')}
          />
        )}
        {screen === 'home' && <OwnerHome store={store} userId={userId} userName={account?.name ?? ''} renderMy={renderMy} onSwitchStore={() => setSwitcher(true)} />}

        {switcher && account && (
          <StoreSwitcher
            acc={account}
            onClose={() => setSwitcher(false)}
            onSelect={async (i) => {
              await changeStore(i);
              setSwitcher(false);
            }}
            onAdd={() => {
              setSwitcher(false);
              setScreen(account.role === 'owner' ? 'o1' : 'f1');
            }}
          />
        )}
      </SafeAreaView>
      </View>
    </SafeAreaProvider>
  );
}
